var searchData=
[
  ['getcolour',['GetColour',['../class_shape.html#a8ffe0f2884373d91dee0eefc62c58768',1,'Shape']]],
  ['getname',['GetName',['../class_shape.html#af4db3280602a9d6be56a0ff3c7b11d4e',1,'Shape']]],
  ['getradius',['GetRadius',['../class_circle.html#a1d5a7069b34da46ae0c3a1160ef5ff29',1,'Circle']]],
  ['getsidelength',['GetSideLength',['../class_square.html#accda78726f7986e834e13838bdc68435',1,'Square']]]
];
